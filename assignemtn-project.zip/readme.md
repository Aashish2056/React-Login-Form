project strcture

api -> db calls
hooks -> store hooks
context -> initialise reducers and context api
pages -> contains pages
components -> store components



componet structure
component -> container -> pages